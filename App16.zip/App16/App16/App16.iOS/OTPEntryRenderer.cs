﻿
using UIKit;
using Xamarin.Forms.Platform.iOS;
using Xamarin.Forms;
using App16;
using App16.iOS;

[assembly: ExportRenderer(typeof(OTPEntry), typeof(OTPEntryRenderer))]
namespace App16.iOS
{
    public class OTPEntryRenderer: EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
            {
                Control.TextContentType = UITextContentType.OneTimeCode;
            }
        }
    }
}
