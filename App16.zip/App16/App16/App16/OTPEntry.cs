﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace App16
{
   public class OTPEntry:Entry
   {

   }
}
